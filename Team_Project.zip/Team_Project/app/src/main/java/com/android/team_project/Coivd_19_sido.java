package com.android.team_project;

import android.os.AsyncTask;

import android.util.Log;
import android.widget.TextView;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class Coivd_19_sido extends AsyncTask<Void, Void, Document> {
    private final String url;
    final TextView textView;

    // 클래스 생성자 : URL 정리 초기화
    Coivd_19_sido(TextView textView) {
        this.textView = textView;
        URL url = null;
        StringBuilder urlBuilder = new StringBuilder(
                "http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19SidoInfStateJson");
        try {
            urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8")
                    + "=re%2B4ZbFs0erT%2Bg5bW2VLp2lNnYogTrEt0R7QKSYaDpZh4g1hbkj8kgaNSL7JTXaXugynM9f8TSqjeODqtP9Dow%3D%3D");
            urlBuilder.append("&" + URLEncoder.encode("ServiceKey", "UTF-8") + "=" + URLEncoder.encode("-", "UTF-8"));
            urlBuilder.append(
                    "&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /* 페이지번호 */
            urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "="
                    + URLEncoder.encode("100000", "UTF-8")); /* 한 페이지 결과 수 */
            urlBuilder.append("&" + URLEncoder.encode("startCreateDt", "UTF-8") + "="
                    + URLEncoder.encode("20210504", "UTF-8")); /* 검색할 생성일 범위의 시작 */
            urlBuilder.append("&" + URLEncoder.encode("endCreateDt", "UTF-8") + "="
                    + URLEncoder.encode("20210504", "UTF-8")); /* 검색할 생성일 범위의 종료 */

            url = new URL(urlBuilder.toString());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        this.url = url.toString();
    }


    // 쓰레드 동작
    // 다큐먼트 만들기
    // doc 반환
    @Override
    protected Document doInBackground(Void... voids) {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;
        Document doc = null;

        try {
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(url);
            doc.getDocumentElement().normalize();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("API", "IOException");
        }
        //Document doc = dBuilder.parse(url.toString());


        return doc;
    }

    @Override
    protected void onPostExecute(Document doc) {
        super.onPostExecute(doc);

        NodeList nList = doc.getElementsByTagName("item");
        Element eElement = (Element) nList.item(0);
        String result = getTagValue("gubun", eElement);
        String result2 = getTagValue("defCnt", eElement);
        textView.setText("지역 : " + result + "\n확진자 수" + result2);
    }

    private static String getTagValue(String tag, Element eElement) {
        try {
            String result = eElement.getElementsByTagName(tag).item(0).getTextContent();
            return result;
        } catch (NullPointerException e) {
            return "";
        } catch (Exception e) {
            return "";
        }
    }
}