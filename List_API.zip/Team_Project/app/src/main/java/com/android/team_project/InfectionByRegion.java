package com.android.team_project;

public class InfectionByRegion {
    String baseDate;
    String region;
    String numberOfInfectedPeople;
    String numberOfIncrease;

    InfectionByRegion(String baseDate, String region, String numberOfInfectedPeople, String numberOfIncrease) {
        this.baseDate = baseDate;
        this.region = region;
        this.numberOfInfectedPeople = numberOfInfectedPeople;
        this.numberOfIncrease = numberOfIncrease;
    }

    public String getData() {
        return "기준일 : " + baseDate + " 지역 : " + region + "확진자 수 : " + numberOfInfectedPeople + " 증감 수 : " + numberOfIncrease;
    }
}
