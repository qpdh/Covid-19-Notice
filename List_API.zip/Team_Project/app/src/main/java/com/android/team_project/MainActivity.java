package com.android.team_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.Vector;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Vector<InfectionByRegion> vector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);

        vector = new Vector<>();

        Coivd_19_sido coivd_19_sido = new Coivd_19_sido();
        Log.d("API", "테스트");


        // 벡터터
        try {
            coivd_19_sido.execute(vector).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < vector.size(); i++) {
            Log.d("MAIN", vector.get(i).getData());
        }


    }
}